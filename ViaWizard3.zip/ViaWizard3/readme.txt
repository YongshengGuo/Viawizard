Windows 7 - Compatibility Properties

*Due to changes in Windows 7 security, it may be necessary to set the compatibility properties for the Via Wizard executable.  
*The Privilege Level for the Via Wizard on Windows 7 should be set to: Run this program as administrator.
*Without changing the Privilege Level, you may receive error messages regarding the improper registration of various ocx controls used by the Via Wizard application
*For more details visit: http://windows.microsoft.com/en-US/windows7/Make-older-programs-run-in-this-version-of-Windows